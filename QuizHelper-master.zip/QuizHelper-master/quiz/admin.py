from django.contrib import admin
from .models import Quiz

# Register your models here.
admin.site.register(Quiz)